-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         5.7.33 - MySQL Community Server (GPL)
-- SO del servidor:              Win64
-- HeidiSQL Versión:             11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Volcando datos para la tabla laravelvue.categories: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`id`, `name`, `description`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
	(669, 'PQRS', 'Peticiones Quejas Reclamos y Sugerencias.', 34, 34, '2022-01-20 00:15:55', '2022-01-20 00:44:51');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.customers: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.details_orders: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `details_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `details_orders` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.files: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
/*!40000 ALTER TABLE `files` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.messages: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.migrations: ~15 rows (aproximadamente)
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2014_04_25_204732_create_files_table', 1),
	(2, '2014_10_12_000000_create_users_table', 1),
	(3, '2014_10_12_100000_create_password_resets_table', 1),
	(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
	(5, '2020_04_25_205358_create_permissions_table', 1),
	(6, '2020_04_25_205514_create_roles_table', 1),
	(7, '2020_04_25_205543_create_users_permissions_table', 1),
	(8, '2020_04_25_205727_create_users_roles_table', 1),
	(9, '2020_04_25_205815_create_roles_permissions_table', 1),
	(10, '2020_04_25_205935_create_messages_table', 1),
	(11, '2020_04_25_210043_create_categories_table', 1),
	(12, '2020_04_25_210147_create_products_table', 1),
	(13, '2020_04_25_210503_create_customers_table', 1),
	(14, '2020_04_25_210710_create_orders_table', 1),
	(15, '2020_04_25_211021_create_details_orders_table', 1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.orders: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.password_resets: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.permissions: ~7 rows (aproximadamente)
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` (`id`, `slug`, `name`, `created_at`, `updated_at`) VALUES
	(2, 'usuario.crear', 'Crear Usuario', '2022-01-16 18:12:13', '2022-01-18 00:23:50'),
	(3, 'usuario.editar', 'Editar Usuarios', '2022-01-16 18:12:13', '2022-01-16 18:12:13'),
	(4, 'usuario.ver', 'Ver Usuarios', '2022-01-16 18:12:13', '2022-01-16 18:12:13'),
	(6, 'usuario.desactivar', 'Desactivar Usuarios', '2022-01-16 18:12:13', '2022-01-16 18:12:13'),
	(7, 'rol.index', 'Navegar Roles', '2022-01-16 18:12:13', '2022-01-16 18:12:13'),
	(12, 'usuario.crearcaso', 'Crear Caso', '2022-01-18 10:56:56', '2022-01-18 10:56:57'),
	(15, 'visualizar.cliente', 'Visualizar', '2022-01-19 22:45:06', NULL);
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.personal_access_tokens: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.products: ~1 rows (aproximadamente)
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` (`id`, `name`, `description`, `categorie_id`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
	(1, 'Queja Telefonica', 'El cliente se encuentra disgustado antes/durante la llamada.', 669, 34, 34, '2022-01-20 01:59:50', '2022-01-20 02:25:54');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.roles: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`id`, `slug`, `name`, `created_at`, `updated_at`) VALUES
	(1, 'administrador.rol', 'Administrador', '2022-01-17 21:01:27', '2022-01-19 02:26:22'),
	(2, 'asesor.rol', 'Asesor', '2022-01-18 08:12:02', '2022-01-18 10:49:18'),
	(3, 'coordinador.rol', 'Coordinador', '2022-01-18 08:12:27', '2022-01-18 08:12:28'),
	(4, 'backoffice.rol', 'BackOffice', '2022-01-19 00:37:56', '2022-01-19 00:37:56'),
	(5, 'cliente.rol', 'Cliente', '2022-01-19 22:45:24', '2022-01-19 22:45:24');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.roles_permissions: ~8 rows (aproximadamente)
/*!40000 ALTER TABLE `roles_permissions` DISABLE KEYS */;
INSERT INTO `roles_permissions` (`role_id`, `permission_id`) VALUES
	(2, 4),
	(4, 2),
	(1, 2),
	(1, 3),
	(1, 4),
	(1, 6),
	(1, 7),
	(1, 12),
	(5, 15);
/*!40000 ALTER TABLE `roles_permissions` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.users: ~25 rows (aproximadamente)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `firstname`, `secondname`, `lastname`, `username`, `email`, `email_verified_at`, `password`, `file_id`, `remember_token`, `created_by`, `updated_by`, `state`, `created_at`, `updated_at`) VALUES
	(2, 'Andrew', 'McNieces', 'Mil', 'architecto.dos', 'sschmitt@example.net', '2022-01-14 18:15:38', '$2y$10$WwZkUW7Pwimzz8WFammHfu62Y06vXfR7jMyHa7fXmggIW.FoROwt.', NULL, 'yo3E0c6ern', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-18 09:43:50'),
	(3, 'Tess', 'Jorge', 'Sauer', 'fugit', 'ezequiel18@example.net', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'IDqDvfpb0w', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-16 03:41:35'),
	(4, 'Mavis', 'Stefanie', 'Hilpert', 'excepturi', 'estel63@example.net', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, '9da3HHzt7H', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(5, 'Myra', 'Watson', 'Casper', 'omnis', 'marielle54@example.net', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'xGSfUK1muB', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-16 03:32:13'),
	(6, 'Eloisa', 'Oran', 'Gerlach', 'dolores', 'pouros.werner@example.org', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'TF9J1XRBIM', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(7, 'Elissa', 'Hiram', 'Ankunding', 'consectetur', 'kfeest@example.com', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'v9WN96ffMh', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(8, 'Joseph', 'Rolando', 'Emmerich', 'sequi', 'britney95@example.com', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, '8DVaWoIpug', 1, 1, 'I', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(9, 'Derek', 'Freda', 'Bartell', 'quae', 'huel.keith@example.org', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'Jmh9I8ILxp', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(10, 'Melvina', 'Alexa', 'Tillman', 'tempora', 'geraldine.quigley@example.org', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'o42WvaMZSP', 1, 1, 'I', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(11, 'Gerard', 'Enrique', 'Raynor', 'laudantium', 'kcarter@example.org', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, '1OvAsqvxOv', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(12, 'Jessie', 'Jordon', 'Crist', 'ut', 'alexandra44@example.net', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'C0bWVgP5T4', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(13, 'Garry', 'Reva', 'Deckow', 'consequatur', 'adrienne.marvin@example.com', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'KRVKw7aV2B', 1, 1, 'I', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(14, 'Zoe', 'Isadore', 'Murphy', 'praesentium', 'jules23@example.org', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'y4dMPRN4qt', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(15, 'Hershel', 'Jeanie', 'Graham', 'asperiores', 'smitham.jan@example.org', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'IDdls2cbRU', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(16, 'Mireille', 'Toby', 'Hartmann', 'et', 'camden.wiegand@example.net', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, '87D5GxH1Sh', 1, 1, 'I', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(17, 'Haven', 'Vernon', 'Gleason', 'harum', 'jedediah76@example.org', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'i2dTP3XBkl', 1, 1, 'I', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(18, 'Annamae', 'Garrett', 'Bradtke', 'numquam', 'gmante@example.org', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'QfBuuu9COX', 1, 1, 'I', '2022-01-14 18:15:38', '2022-01-20 00:49:46'),
	(19, 'Brooks', 'Arnaldo', 'Schmeler', 'natus', 'ratke.adell@example.net', '2022-01-14 18:15:38', '$2y$10$yx4u5yDa.3fPOQSRUUDzneok0cc02llawHfb4UXohh1wZX1Fpq8Tq', NULL, 'T3qNEMSryX', 1, 1, 'I', '2022-01-14 18:15:38', '2022-01-20 00:48:05'),
	(20, 'Javon', 'Katheryn', 'Carter', 'sed', 'annabel28@example.com', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'gVZKaNZPVW', 1, 1, 'I', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(21, 'Ida', 'Charlotte', 'Ankunding', 'consequuntur', 'schmeler.keven@example.net', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, '84oNgr8Zna', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(22, 'David', '', 'Cordoba Pimienta', 'david.cordoba', 'david.cordoba@grupokonecta.com', '2022-01-18 23:14:37', '$2y$10$cTC3BNxBwIa.NJUczR81xOqS/83a5Hrqaf7nnZ1uBhRqFYJ.W7D6i', NULL, NULL, 1, 1, 'A', '2022-01-16 00:07:02', '2022-01-19 22:32:31'),
	(27, 'Esneider', '', 'Velez Peña', 'esneider.velez', 'esvelpe@gmail.com', NULL, '111', NULL, NULL, 1, 1, 'A', '2022-01-16 02:30:38', '2022-01-16 02:44:13'),
	(28, 'Sandra', 'Patricia', 'Mateus', 'spmateus.poli', 'spmateus@elpoli.edu.co', NULL, '$2y$10$3YT.m293Gbj.EJ85uFaQ7eWKaBcQh4emnL.tk.URvPTiEyuvvcZC2', NULL, NULL, 1, 1, 'A', '2022-01-16 03:09:33', '2022-01-20 03:05:24'),
	(34, 'Administrador', '', '', 'Admin', 'Admin', NULL, '$2y$10$q4b4FZqfIoUTTO4t4q8oXuJhEGDOhmUckSI5h1LNMfdUJvnNukxHS', NULL, NULL, 1, 1, 'A', '2022-01-18 09:16:19', '2022-01-19 02:33:40'),
	(35, 'r', 'r', 'r', 'r', 'r', NULL, '$2y$10$MOecS5Yfut2SmaqMqfVUeefUrqWYi1ak3xWF/Ofqq2bVr0ne3VBza', NULL, NULL, 1, 1, 'I', '2022-01-19 01:02:18', '2022-01-20 03:05:05'),
	(36, 'F', 'F', 'F', 'F', 'F', NULL, '$2y$10$kOD7lzXzrjYC2qQTOTaIhOfXXNM.xV9EApHqHlhnGLVWHOgKRaYia', NULL, NULL, 1, 1, 'I', '2022-01-19 22:56:42', '2022-01-19 22:56:52');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.users_permissions: ~7 rows (aproximadamente)
/*!40000 ALTER TABLE `users_permissions` DISABLE KEYS */;
INSERT INTO `users_permissions` (`user_id`, `permission_id`) VALUES
	(34, 4),
	(34, 7),
	(34, 3),
	(34, 6),
	(34, 2),
	(34, 12),
	(22, 4),
	(22, 12);
/*!40000 ALTER TABLE `users_permissions` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.users_roles: ~6 rows (aproximadamente)
/*!40000 ALTER TABLE `users_roles` DISABLE KEYS */;
INSERT INTO `users_roles` (`user_id`, `role_id`) VALUES
	(34, 1),
	(2, 2),
	(19, 2),
	(35, 1),
	(22, 2),
	(36, 5),
	(28, 1);
/*!40000 ALTER TABLE `users_roles` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
