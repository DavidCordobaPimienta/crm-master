-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         5.7.33 - MySQL Community Server (GPL)
-- SO del servidor:              Win64
-- HeidiSQL Versión:             11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Volcando datos para la tabla laravelvue.categories: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.customers: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.details_orders: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `details_orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `details_orders` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.files: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
/*!40000 ALTER TABLE `files` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.messages: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.migrations: ~15 rows (aproximadamente)
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2014_04_25_204732_create_files_table', 1),
	(2, '2014_10_12_000000_create_users_table', 1),
	(3, '2014_10_12_100000_create_password_resets_table', 1),
	(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
	(5, '2020_04_25_205358_create_permissions_table', 1),
	(6, '2020_04_25_205514_create_roles_table', 1),
	(7, '2020_04_25_205543_create_users_permissions_table', 1),
	(8, '2020_04_25_205727_create_users_roles_table', 1),
	(9, '2020_04_25_205815_create_roles_permissions_table', 1),
	(10, '2020_04_25_205935_create_messages_table', 1),
	(11, '2020_04_25_210043_create_categories_table', 1),
	(12, '2020_04_25_210147_create_products_table', 1),
	(13, '2020_04_25_210503_create_customers_table', 1),
	(14, '2020_04_25_210710_create_orders_table', 1),
	(15, '2020_04_25_211021_create_details_orders_table', 1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.orders: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.password_resets: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.permissions: ~7 rows (aproximadamente)
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` (`id`, `slug`, `name`, `created_at`, `updated_at`) VALUES
	(1, 'usuario.index', 'Navegar Usuarios', '2022-01-16 18:07:00', '2022-01-16 18:07:00'),
	(2, 'usuario.crear', 'Crear Usuarios', '2022-01-16 18:12:13', '2022-01-16 18:12:13'),
	(3, 'usuario.editar', 'Editar Usuarios', '2022-01-16 18:12:13', '2022-01-16 18:12:13'),
	(4, 'usuario.ver', 'Ver Usuarios', '2022-01-16 18:12:13', '2022-01-16 18:12:13'),
	(5, 'usuario.activar', 'Activar Usuarios', '2022-01-16 18:12:13', '2022-01-16 18:12:13'),
	(6, 'usuario.desactivar', 'Desactivar Usuarios', '2022-01-16 18:12:13', '2022-01-16 18:12:13'),
	(7, 'rol.index', 'Navegar Roles', '2022-01-16 18:12:13', '2022-01-16 18:12:13');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.personal_access_tokens: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.products: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
/*!40000 ALTER TABLE `products` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.roles: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.roles_permissions: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `roles_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `roles_permissions` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.users: ~23 rows (aproximadamente)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `firstname`, `secondname`, `lastname`, `username`, `email`, `email_verified_at`, `password`, `file_id`, `remember_token`, `created_by`, `updated_by`, `state`, `created_at`, `updated_at`) VALUES
	(2, 'Andrew', 'McNieces', 'Mil', 'architecto.dos', 'sschmitt@example.net', '2022-01-14 18:15:38', '$2y$10$Zyk/eFFnc8xbMg7.aTBDw.uqo8XRYvul8gHJ7k44kGnQ3AIi8MKr2', NULL, 'yo3E0c6ern', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-16 16:33:14'),
	(3, 'Tess', 'Jorge', 'Sauer', 'fugit', 'ezequiel18@example.net', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'IDqDvfpb0w', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-16 03:41:35'),
	(4, 'Mavis', 'Stefanie', 'Hilpert', 'excepturi', 'estel63@example.net', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, '9da3HHzt7H', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(5, 'Myra', 'Watson', 'Casper', 'omnis', 'marielle54@example.net', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'xGSfUK1muB', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-16 03:32:13'),
	(6, 'Eloisa', 'Oran', 'Gerlach', 'dolores', 'pouros.werner@example.org', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'TF9J1XRBIM', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(7, 'Elissa', 'Hiram', 'Ankunding', 'consectetur', 'kfeest@example.com', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'v9WN96ffMh', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(8, 'Joseph', 'Rolando', 'Emmerich', 'sequi', 'britney95@example.com', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, '8DVaWoIpug', 1, 1, 'I', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(9, 'Derek', 'Freda', 'Bartell', 'quae', 'huel.keith@example.org', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'Jmh9I8ILxp', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(10, 'Melvina', 'Alexa', 'Tillman', 'tempora', 'geraldine.quigley@example.org', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'o42WvaMZSP', 1, 1, 'I', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(11, 'Gerard', 'Enrique', 'Raynor', 'laudantium', 'kcarter@example.org', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, '1OvAsqvxOv', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(12, 'Jessie', 'Jordon', 'Crist', 'ut', 'alexandra44@example.net', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'C0bWVgP5T4', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(13, 'Garry', 'Reva', 'Deckow', 'consequatur', 'adrienne.marvin@example.com', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'KRVKw7aV2B', 1, 1, 'I', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(14, 'Zoe', 'Isadore', 'Murphy', 'praesentium', 'jules23@example.org', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'y4dMPRN4qt', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(15, 'Hershel', 'Jeanie', 'Graham', 'asperiores', 'smitham.jan@example.org', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'IDdls2cbRU', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(16, 'Mireille', 'Toby', 'Hartmann', 'et', 'camden.wiegand@example.net', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, '87D5GxH1Sh', 1, 1, 'I', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(17, 'Haven', 'Vernon', 'Gleason', 'harum', 'jedediah76@example.org', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'i2dTP3XBkl', 1, 1, 'I', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(18, 'Annamae', 'Garrett', 'Bradtke', 'numquam', 'gmante@example.org', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'QfBuuu9COX', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(19, 'Brooks', 'Arnaldo', 'Schmeler', 'natus', 'ratke.adell@example.net', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'T3qNEMSryX', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(20, 'Javon', 'Katheryn', 'Carter', 'sed', 'annabel28@example.com', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'gVZKaNZPVW', 1, 1, 'I', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(21, 'Ida', 'Charlotte', 'Ankunding', 'consequuntur', 'schmeler.keven@example.net', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, '84oNgr8Zna', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(22, 'David', '', 'Cordoba Pimienta', 'david.cordoba', 'david_cordoba82161@elpoli.edu.co', NULL, '$2y$10$4D2QX2FEVrtUTCJPX//heeBoW6heCBTm.CfnlIuJvJTCbEUD3dtMa', NULL, NULL, 1, 1, 'A', '2022-01-16 00:07:02', '2022-01-16 02:43:27'),
	(27, 'Esneider', '', 'Velez Peña', 'esneider.velez', 'esvelpe@gmail.com', NULL, '$2y$10$mhqTYGkHZkhEbXiG9hRiuu0ihlEh4NBdnDx87X3qb9Vx8VsWqKFwW', NULL, NULL, 1, 1, 'A', '2022-01-16 02:30:38', '2022-01-16 02:44:13'),
	(28, 'Sandra', 'Patricia', 'Mateus', 'spmateus.poli', 'davidcordobapimienta1@gmail.com', NULL, '$2y$10$NIMFWBYKknARWt8bfwvIS.J1BSm6xADycxOuvDfWgfUimfnkHA8ka', NULL, NULL, 1, 1, 'A', '2022-01-16 03:09:33', NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.users_permissions: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `users_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_permissions` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.users_roles: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `users_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `users_roles` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
