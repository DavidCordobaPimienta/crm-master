-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         5.7.33 - MySQL Community Server (GPL)
-- SO del servidor:              Win64
-- HeidiSQL Versión:             11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Volcando datos para la tabla laravelvue.categories: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` (`id`, `name`, `description`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
	(669, 'PQRS', 'Peticiones Quejas Reclamos y Sugerencias.', 34, 34, '2022-01-20 00:15:55', '2022-01-20 00:44:51'),
	(670, 'Cajero Automatico', 'Cajero Automático no devuelve.', 34, 34, '2022-01-20 09:45:26', '2022-01-20 09:45:26'),
	(671, 'Perdidas/Robos', 'Productos del grupo Bancolombia y aliados con desconocimiento de su paradero.', 35, 35, '2022-01-24 01:37:16', '2022-01-24 01:37:16');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.customers: ~6 rows (aproximadamente)
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` (`id`, `name`, `lastname`, `document`, `phone`, `email`, `created_by`, `updated_by`, `created_at`, `updated_at`) VALUES
	(12, 'David', 'Córdoba Pimienta', '1033662783', '3217684049', 'david@gmail.com', 35, 35, '2022-01-23 04:32:42', '2022-01-24 00:45:55'),
	(13, 'Esneider', 'Velez', '1111111', '3132313', '0', 35, 35, '2022-01-23 04:49:36', '2022-01-23 04:49:36'),
	(14, '123', '123', '123', '123', '0', 35, 35, '2022-01-23 20:18:32', '2022-01-23 20:18:32'),
	(15, 'MARLENY', 'Pimienta', '0000000000', '3217684049', '0', 35, 35, '2022-01-23 20:33:39', '2022-01-23 20:33:39'),
	(16, 'David', 'Pimienta', '1234566890', '3217684049', '0', 35, 35, '2022-01-24 00:24:47', '2022-01-24 00:24:47'),
	(17, 'sdsd', 'sdsd', 'sdsdsdsd', '3217684049', '0', 35, 35, '2022-01-24 00:26:31', '2022-01-24 00:26:31');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.details_orders: ~44 rows (aproximadamente)
/*!40000 ALTER TABLE `details_orders` DISABLE KEYS */;
INSERT INTO `details_orders` (`order_id`, `product_id`, `quantity`, `price`, `created_at`, `updated_at`) VALUES
	(3, 2, 12, 12, NULL, NULL),
	(4, 2, 12, 12, NULL, NULL),
	(4, 1, 12, 12, NULL, NULL),
	(4, 1, 12, 12, NULL, NULL),
	(5, 2, 12, 12, NULL, NULL),
	(6, 2, 12, 12, NULL, NULL),
	(7, 2, 12, 12, NULL, NULL),
	(8, 2, 12, 12, NULL, NULL),
	(9, 2, 12, 12, NULL, NULL),
	(10, 1, 12, 12, NULL, NULL),
	(11, 2, 12, 12, NULL, NULL),
	(12, 1, 12, 12, NULL, NULL),
	(13, 2, 12, 12, NULL, NULL),
	(14, 2, 12, 12, NULL, NULL),
	(15, 2, 12, 12, NULL, NULL),
	(17, 2, 12, 12, NULL, NULL),
	(18, 2, 12, 12, NULL, NULL),
	(19, 2, 12, 12, NULL, NULL),
	(20, 2, 12, 12, NULL, NULL),
	(21, 2, 12, 12, NULL, NULL),
	(22, 2, 12, 12, NULL, NULL),
	(23, 2, 12, 12, NULL, NULL),
	(24, 2, 12, 12, NULL, NULL),
	(25, 2, 12, 12, NULL, NULL),
	(26, 2, 12, 12, NULL, NULL),
	(27, 2, 12, 12, NULL, NULL),
	(30, 2, 12, 12, NULL, NULL),
	(31, 2, 12, 12, NULL, NULL),
	(33, 2, 12, 12, NULL, NULL),
	(34, 2, 12, 12, NULL, NULL),
	(35, 2, 12, 12, NULL, NULL),
	(36, 2, 12, 12, NULL, NULL),
	(37, 2, 12, 12, NULL, NULL),
	(38, 1, 12, 12, NULL, NULL),
	(39, 2, 12, 12, NULL, NULL),
	(40, 2, 12, 12, NULL, NULL),
	(41, 2, 12, 12, NULL, NULL),
	(42, 2, 12, 12, NULL, NULL),
	(43, 1, 12, 12, NULL, NULL),
	(43, 2, 12, 12, NULL, NULL),
	(44, 3, 12, 12, NULL, NULL),
	(45, 4, 12, 12, NULL, NULL),
	(46, 4, 12, 12, NULL, NULL),
	(47, 5, 12, 12, NULL, NULL),
	(48, 5, 12, 12, NULL, NULL),
	(49, 3, 12, 12, NULL, NULL),
	(50, 4, 12, 12, NULL, NULL);
/*!40000 ALTER TABLE `details_orders` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.files: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
/*!40000 ALTER TABLE `files` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.messages: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.migrations: ~15 rows (aproximadamente)
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
	(1, '2014_04_25_204732_create_files_table', 1),
	(2, '2014_10_12_000000_create_users_table', 1),
	(3, '2014_10_12_100000_create_password_resets_table', 1),
	(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
	(5, '2020_04_25_205358_create_permissions_table', 1),
	(6, '2020_04_25_205514_create_roles_table', 1),
	(7, '2020_04_25_205543_create_users_permissions_table', 1),
	(8, '2020_04_25_205727_create_users_roles_table', 1),
	(9, '2020_04_25_205815_create_roles_permissions_table', 1),
	(10, '2020_04_25_205935_create_messages_table', 1),
	(11, '2020_04_25_210043_create_categories_table', 1),
	(12, '2020_04_25_210147_create_products_table', 1),
	(13, '2020_04_25_210503_create_customers_table', 1),
	(14, '2020_04_25_210710_create_orders_table', 1),
	(15, '2020_04_25_211021_create_details_orders_table', 1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.orders: ~39 rows (aproximadamente)
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` (`id`, `order_number`, `comments`, `customer_id`, `user_id`, `total`, `created_by`, `updated_by`, `state`, `created_at`, `updated_at`) VALUES
	(3, '20221233', 'PRUEBA', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 04:34:22', '2022-01-23 04:34:22'),
	(4, '20221234', 'Hola!', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 04:43:45', '2022-01-23 04:43:45'),
	(5, '20221235', 'El cliente obtuvo billete falso.', 13, 35, 1.00, 35, 35, 'A', '2022-01-23 04:49:37', '2022-01-23 04:49:37'),
	(6, '20221236', 'PRUEBAAAA', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 19:34:06', '2022-01-23 19:34:06'),
	(7, '20221237', 'DDD', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 19:34:26', '2022-01-23 19:34:26'),
	(8, '20221238', '', 12, 35, 1.00, 35, 35, 'I', '2022-01-23 19:35:01', '2022-01-23 22:47:40'),
	(9, '20221239', 'aaaaaaa', 12, 35, 1.00, 35, 35, 'I', '2022-01-23 19:35:58', '2022-01-23 22:46:41'),
	(10, '202212310', '', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 19:36:32', '2022-01-23 19:36:32'),
	(11, '202212311', '', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 19:37:58', '2022-01-23 19:37:58'),
	(12, '202212312', '111111111111111', 13, 35, 1.00, 35, 35, 'A', '2022-01-23 19:38:38', '2022-01-23 19:38:38'),
	(13, '202212313', 'PRUEBA KOECTA', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 19:39:59', '2022-01-23 19:39:59'),
	(14, '202212314', 'blue', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 19:41:56', '2022-01-23 19:41:56'),
	(15, '202212315', '', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 19:43:27', '2022-01-23 19:43:27'),
	(17, '202212317', '', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 19:45:53', '2022-01-23 19:45:53'),
	(18, '202212318', '', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 19:46:54', '2022-01-23 19:46:54'),
	(19, '202212319', '', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 19:47:53', '2022-01-23 19:47:53'),
	(20, '202212320', '', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 19:48:13', '2022-01-23 19:48:13'),
	(21, '202212321', '', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 19:48:14', '2022-01-23 19:48:14'),
	(22, '202212322', '', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 19:48:15', '2022-01-23 19:48:15'),
	(23, '202212323', '', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 19:48:15', '2022-01-23 19:48:15'),
	(24, '202212324', '', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 19:48:16', '2022-01-23 19:48:16'),
	(25, '202212325', '', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 19:48:20', '2022-01-23 19:48:20'),
	(26, '202212326', '', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 19:48:50', '2022-01-23 19:48:50'),
	(27, '202212327', 'PRUEBA KOECTA', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 19:50:26', '2022-01-23 19:50:26'),
	(30, '202212330', '22222222222222', 13, 35, 1.00, 35, 35, 'A', '2022-01-23 19:53:59', '2022-01-23 19:53:59'),
	(31, '202212331', '333333333333333', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 19:54:34', '2022-01-23 19:54:34'),
	(33, '202212333', '777777777777777777', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 19:55:32', '2022-01-23 19:55:32'),
	(34, '202212334', '1111111', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 19:58:00', '2022-01-23 19:58:00'),
	(35, '202212335', 'rio', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 20:03:45', '2022-01-23 20:03:45'),
	(36, '202212336', 'rio blue', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 20:08:16', '2022-01-23 20:08:16'),
	(37, '202212337', 'PRUEBA KOECTA', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 20:09:45', '2022-01-23 20:09:45'),
	(38, '202212338', '11111', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 20:10:12', '2022-01-23 20:10:12'),
	(39, '202212339', '111111111', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 20:12:49', '2022-01-23 20:12:49'),
	(40, '202212340', '11111aaaaaa', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 20:13:36', '2022-01-23 20:13:36'),
	(41, '202212341', '111111111122222222233333333333333333', 14, 35, 1.00, 35, 35, 'A', '2022-01-23 20:18:32', '2022-01-23 20:18:32'),
	(42, '202212342', 'Reportado en la sucursal de CC Molinos', 12, 35, 1.00, 35, 35, 'A', '2022-01-23 20:30:40', '2022-01-23 20:30:40'),
	(43, '202212343', 'CREADO CON CLIENTE NUEVO', 15, 35, 1.00, 35, 35, 'A', '2022-01-23 20:33:39', '2022-01-23 20:33:39'),
	(44, '202212344', 'Sucedió en ditarires.', 13, 35, 1.00, 35, 35, 'A', '2022-01-23 20:39:38', '2022-01-23 20:39:38'),
	(45, '202212445', 'PRUEBA KONECTA', 12, 35, 1.00, 35, 35, 'A', '2022-01-24 00:00:00', '2022-01-24 02:24:42'),
	(46, '202212446', 'aaaaaaaaaaaadddddddddddd', 17, 35, 1.00, 35, 35, 'A', '2022-01-24 02:26:05', '2022-01-24 02:26:05'),
	(47, '202212447', 'qqqqqqqqq', 12, 35, 1.00, 35, 35, 'A', '2022-01-24 02:26:27', '2022-01-24 02:26:27'),
	(48, '202212448', 'PRUEBA KONECTA', 12, 35, 1.00, 35, 35, 'A', '2022-01-24 02:26:48', '2022-01-24 02:26:48'),
	(49, '202212449', '', 12, 34, 1.00, 34, 34, 'A', '2022-01-24 15:35:56', '2022-01-24 15:35:56'),
	(50, '202212450', '', 16, 34, 1.00, 34, 34, 'A', '2022-01-24 15:37:29', '2022-01-24 15:37:29');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.password_resets: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.permissions: ~7 rows (aproximadamente)
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` (`id`, `slug`, `name`, `created_at`, `updated_at`) VALUES
	(2, 'usuario.crear', 'Crear Usuario', '2022-01-16 18:12:13', '2022-01-18 00:23:50'),
	(3, 'usuario.editar', 'Editar Usuarios', '2022-01-16 18:12:13', '2022-01-16 18:12:13'),
	(4, 'usuario.ver', 'Ver Usuarios', '2022-01-16 18:12:13', '2022-01-16 18:12:13'),
	(6, 'usuario.desactivar', 'Desactivar Usuarios', '2022-01-16 18:12:13', '2022-01-16 18:12:13'),
	(7, 'rol.index', 'Navegar Roles', '2022-01-16 18:12:13', '2022-01-16 18:12:13'),
	(12, 'usuario.crearcaso', 'Crear Casos', '2022-01-18 10:56:56', '2022-01-20 09:40:25'),
	(15, 'visualizar.cliente', 'Visualizar', '2022-01-19 22:45:06', NULL),
	(16, 'cuentas.ver', 'Ver Cuentas', '2022-01-20 09:41:15', NULL);
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.personal_access_tokens: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.products: ~4 rows (aproximadamente)
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` (`id`, `name`, `description`, `categorie_id`, `created_by`, `updated_by`, `created_at`, `updated_at`, `stock`) VALUES
	(1, 'Queja Telefonica', 'El cliente se encuentra disgustado antes o durante la llamada.', 669, 34, 34, '2022-01-20 01:59:50', '2022-01-20 09:44:55', 111),
	(2, 'Billete Falso', 'El cajero automático devuelve billete falso o papel', 670, 34, 34, '2022-01-20 09:46:49', '2022-01-20 09:47:08', 111),
	(3, 'Retención de Tarjetas', 'El cajero retiene tarjeta debito sin posibilidades de extraer.', 670, 35, 35, '2022-01-23 20:39:12', '2022-01-24 01:36:23', NULL),
	(4, 'Perdida TDC', 'La tarjeta de credito no fue robada o se tiene plena seguridad de su pérdida.', 671, 35, 35, '2022-01-24 01:37:56', '2022-01-24 01:37:56', NULL),
	(5, 'Robo TD', 'La tarjeta débito fue robada con certeza en un atraco o asalto.', 671, 35, 35, '2022-01-24 01:38:53', '2022-01-24 01:38:53', NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.roles: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` (`id`, `slug`, `name`, `created_at`, `updated_at`) VALUES
	(1, 'administrador.rol', 'Administrador', '2022-01-17 21:01:27', '2022-01-19 02:26:22'),
	(2, 'asesor.rol', 'Asesor', '2022-01-18 08:12:02', '2022-01-18 10:49:18'),
	(3, 'coordinador.rol', 'Coordinador', '2022-01-18 08:12:27', '2022-01-18 08:12:28'),
	(4, 'backoffice.rol', 'BackOffice', '2022-01-19 00:37:56', '2022-01-24 15:39:51');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.roles_permissions: ~10 rows (aproximadamente)
/*!40000 ALTER TABLE `roles_permissions` DISABLE KEYS */;
INSERT INTO `roles_permissions` (`role_id`, `permission_id`) VALUES
	(2, 4),
	(1, 2),
	(1, 3),
	(1, 4),
	(1, 6),
	(1, 7),
	(1, 12),
	(4, 2),
	(4, 4),
	(4, 7);
/*!40000 ALTER TABLE `roles_permissions` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.users: ~28 rows (aproximadamente)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `firstname`, `secondname`, `lastname`, `username`, `email`, `email_verified_at`, `password`, `file_id`, `remember_token`, `created_by`, `updated_by`, `state`, `created_at`, `updated_at`) VALUES
	(2, 'Andrew', 'McNieces', 'Mil', 'architecto.dos', 'sschmitt@example.net', '2022-01-14 18:15:38', '$2y$10$WwZkUW7Pwimzz8WFammHfu62Y06vXfR7jMyHa7fXmggIW.FoROwt.', NULL, 'yo3E0c6ern', 1, 35, 'A', '2022-01-14 18:15:38', '2022-01-22 22:23:23'),
	(3, 'Tess', 'Jorge', 'Sauer', 'fugit', 'ezequiel18@example.net', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'IDqDvfpb0w', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-16 03:41:35'),
	(4, 'Mavis', 'Stefanie', 'Hilpert', 'excepturi', 'estel63@example.net', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, '9da3HHzt7H', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(5, 'Myra', 'Watson', 'Casper', 'omnis', 'marielle54@example.net', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'xGSfUK1muB', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-16 03:32:13'),
	(6, 'Eloisa', 'Oran', 'Gerlach', 'dolores', 'pouros.werner@example.org', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'TF9J1XRBIM', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(7, 'Elissa', 'Hiram', 'Ankunding', 'consectetur', 'kfeest@example.com', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'v9WN96ffMh', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(8, 'Joseph', 'Rolando', 'Emmerich', 'sequi', 'britney95@example.com', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, '8DVaWoIpug', 1, 1, 'I', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(9, 'Derek', 'Freda', 'Bartell', 'quae', 'huel.keith@example.org', '2022-01-14 18:15:38', '$2y$10$3cWenPsFAqZce2uhKdJroO6mMtfw3e.w1ipPLRlYiDyX4LbpM/P4O', NULL, 'Jmh9I8ILxp', 1, 34, 'A', '2022-01-14 18:15:38', '2022-01-20 07:15:01'),
	(10, 'Melvina', 'Alexa', 'Tillman', 'tempora', 'geraldine.quigley@example.org', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'o42WvaMZSP', 1, 1, 'I', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(11, 'Gerard', 'Enrique', 'Raynor', 'laudantium', 'kcarter@example.org', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, '1OvAsqvxOv', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(12, 'Jessie', 'Jordon', 'Crist', 'ut', 'alexandra44@example.net', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'C0bWVgP5T4', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(13, 'Garry', 'Reva', 'Deckow', 'consequatur', 'adrienne.marvin@example.com', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'KRVKw7aV2B', 1, 1, 'I', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(14, 'Zoe', 'Isadore', 'Murphy', 'praesentium', 'jules23@example.org', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'y4dMPRN4qt', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(15, 'Hershel', 'Jeanie', 'Graham', 'asperiores', 'smitham.jan@example.org', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'IDdls2cbRU', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(16, 'Mireille', 'Toby', 'Hartmann', 'et', 'camden.wiegand@example.net', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, '87D5GxH1Sh', 1, 1, 'I', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(17, 'Haven', 'Vernon', 'Gleason', 'harum', 'jedediah76@example.org', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'i2dTP3XBkl', 1, 1, 'I', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(18, 'Annamae', 'Garrett', 'Bradtke', 'numquam', 'gmante@example.org', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'QfBuuu9COX', 1, 34, 'A', '2022-01-14 18:15:38', '2022-01-20 07:16:20'),
	(19, 'Brooks', 'Arnaldo', 'Schmeler', 'natus', 'ratke.adell@example.net', '2022-01-14 18:15:38', '$2y$10$yx4u5yDa.3fPOQSRUUDzneok0cc02llawHfb4UXohh1wZX1Fpq8Tq', NULL, 'T3qNEMSryX', 1, 35, 'A', '2022-01-14 18:15:38', '2022-01-22 22:23:04'),
	(20, 'Javon', 'Katheryn', 'Carter', 'sed', 'annabel28@example.com', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, 'gVZKaNZPVW', 1, 1, 'I', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(21, 'Ida', 'Charlotte', 'Ankunding', 'consequuntur', 'schmeler.keven@example.net', '2022-01-14 18:15:38', '$contraseñakonecta2022*', NULL, '84oNgr8Zna', 1, 1, 'A', '2022-01-14 18:15:38', '2022-01-14 18:15:38'),
	(22, 'David', '', 'Cordoba Pimienta', 'david.cordoba', 'david.cordoba@grupokonecta.com', '2022-01-18 23:14:37', '$2y$10$cTC3BNxBwIa.NJUczR81xOqS/83a5Hrqaf7nnZ1uBhRqFYJ.W7D6i', NULL, NULL, 1, 1, 'A', '2022-01-16 00:07:02', '2022-01-19 22:32:31'),
	(27, 'Esneider', '', 'Velez Peña', 'esneider.velez', 'esvelpe@gmail.com', NULL, '111', NULL, NULL, 1, 1, 'A', '2022-01-16 02:30:38', '2022-01-16 02:44:13'),
	(28, 'Sandra', 'Patricia', 'Mateus', 'spmateus.poli', 'spmateus@elpoli.edu.co', NULL, '$2y$10$3YT.m293Gbj.EJ85uFaQ7eWKaBcQh4emnL.tk.URvPTiEyuvvcZC2', NULL, NULL, 1, 1, 'A', '2022-01-16 03:09:33', '2022-01-20 03:05:24'),
	(34, 'Administrador', '', 'Konecta', 'Admin', 'Admin', NULL, '$2y$10$YwfK3f9Xcnj4YlmQGRn1auR8PfFmTIK/x9.l34k3AJgCJ7NC0xqP2', NULL, NULL, 1, 34, 'A', '2022-01-18 09:16:19', '2022-01-24 15:36:24'),
	(35, 'r', 'r', 'r', 'r', 'r', NULL, '$2y$10$MOecS5Yfut2SmaqMqfVUeefUrqWYi1ak3xWF/Ofqq2bVr0ne3VBza', NULL, NULL, 1, 1, 'A', '2022-01-19 01:02:18', '2022-01-20 03:05:05'),
	(36, 'F', 'F', 'F', 'F', 'F', NULL, '$2y$10$kOD7lzXzrjYC2qQTOTaIhOfXXNM.xV9EApHqHlhnGLVWHOgKRaYia', NULL, NULL, 1, 1, 'I', '2022-01-19 22:56:42', '2022-01-19 22:56:52'),
	(37, 'u', 'u', 'u', 'u', 'u', NULL, '$2y$10$jsaC3b2/01DtvkTNZOIlk.MtzPVwDruJ2VHbzmrEG7MvZojpUnEKu', NULL, NULL, 34, 35, 'A', '2022-01-20 07:13:21', '2022-01-22 22:23:19'),
	(38, 'Ensayo 20', 'Enero', 'Pimienta', 'david.cordoba', 'davidcordobapimienta1@gmail.com', NULL, '$2y$10$ABsDvcSJ7nD4G156OBox..E17hFusj.69lPHM/h2RLMiDkCX48kwW', NULL, NULL, 34, 34, 'A', '2022-01-20 09:32:47', '2022-01-20 09:33:33');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.users_permissions: ~7 rows (aproximadamente)
/*!40000 ALTER TABLE `users_permissions` DISABLE KEYS */;
INSERT INTO `users_permissions` (`user_id`, `permission_id`) VALUES
	(34, 4),
	(34, 7),
	(34, 3),
	(34, 6),
	(34, 2),
	(34, 12),
	(22, 4),
	(22, 12);
/*!40000 ALTER TABLE `users_permissions` ENABLE KEYS */;

-- Volcando datos para la tabla laravelvue.users_roles: ~8 rows (aproximadamente)
/*!40000 ALTER TABLE `users_roles` DISABLE KEYS */;
INSERT INTO `users_roles` (`user_id`, `role_id`) VALUES
	(34, 1),
	(2, 2),
	(19, 2),
	(35, 1),
	(22, 2),
	(28, 1),
	(37, 1),
	(9, 2),
	(38, 1);
/*!40000 ALTER TABLE `users_roles` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
